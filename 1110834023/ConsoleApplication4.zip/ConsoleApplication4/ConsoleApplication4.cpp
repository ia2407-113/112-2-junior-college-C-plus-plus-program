﻿#include "airliner.h"

int main()
{
    flight_object* flight;
    flight_object flight1;
    airliner air1;  // 兼具空中及水上功能 

    flight = &flight1;
    flight->display();  


    flight = &air1;
    flight->display();  

    return 0;
}
