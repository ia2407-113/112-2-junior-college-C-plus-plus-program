﻿#include "flight.h"

int main() {
    airliner air1;
    air1.display();
    air1.display_airliner();

    return 0;
}
