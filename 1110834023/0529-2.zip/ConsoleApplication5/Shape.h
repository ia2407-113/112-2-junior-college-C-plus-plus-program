#ifndef SHAPE_H
#define SHAPE_H

#include <string>

class Shape {
public:
    std::string name;   
    double shape_area;  

   
    virtual void area();
};

#endif
