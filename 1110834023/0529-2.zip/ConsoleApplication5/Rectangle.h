#ifndef RECTANGLE_H
#define RECTANGLE_H

#include "Shape.h"

class Rectangle : public Shape {
public:
    double length;  // ��
    double width;   // �e

    // ��J���P�e
    void data_input();

    // ���n
    void area() override;
};

#endif
#pragma once
