#ifndef CUBE_H
#define CUBE_H

#include "Rectangle.h"


class Cube : public Rectangle {
public:
    double height;  

   
    void data_input();

    void volume();
};

#endif

