﻿#include <iostream>
#include "Cube.h"

int main() {
    Cube myCube;

    myCube.data_input();

    myCube.area();
    std::cout << myCube.name << " 的面積為: " << myCube.shape_area << std::endl;

 
    myCube.volume();

    return 0;
}
