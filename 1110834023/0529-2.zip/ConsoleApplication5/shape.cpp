#include "Shape.h"

void Shape::area() {
    shape_area = 0;
}
