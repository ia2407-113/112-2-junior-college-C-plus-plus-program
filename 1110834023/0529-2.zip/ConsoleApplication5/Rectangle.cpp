#include <iostream>
#include "Rectangle.h"

void Rectangle::data_input() {
    std::cout << "�п�J����Ϊ�: ";
    std::cin >> length;
    std::cout << "�п�J����μe: ";
    std::cin >> width;
}

void Rectangle::area() {
    shape_area = length * width;
    name = "Rectangle";
}
