﻿#include <iostream>

int main() {
    int n = 9; // 初始行數
    for (int i = n; i >= 1; i -= 2) {   //每層遞減一層會減2
        for (int j = 1; j <= i; ++j) {  
            std::cout << j;   //輸出結果會呈現減2的結果
        }
        std::cout << std::endl;
    }
    return 0;
}
