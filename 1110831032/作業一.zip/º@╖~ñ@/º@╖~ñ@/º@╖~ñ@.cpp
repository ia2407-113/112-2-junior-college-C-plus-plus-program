﻿#include <iostream>

int main() {
    int n;
    double sum = 0.0;

    std::cout << "請輸入一個小於50的正整數n：";
    std::cin >> n;  //比較是否符合資格

    if (n >= 50) {
        std::cout << "n 大於等於 50，終止程式。\n";  //大於50終止程式
        return 1;
    }

    for (int i = 1; i <= n; ++i) {  //計算式
        sum += 1.0 / i;
    }

    std::cout << "1 + 1/2 + 1/3 + ... + 1/" << n << " = " << sum << "\n";

    return 0;
}
