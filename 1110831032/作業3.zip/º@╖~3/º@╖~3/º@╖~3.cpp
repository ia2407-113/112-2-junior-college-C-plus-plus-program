﻿#include <iostream>
using namespace std;

int main() {
    int password;
    int attempts = 0;
    const int max_attempts = 3;   //限制三次

    do {
        cout << "請輸入密碼：";    //輸入密碼
        cin >> password;
        attempts++;

        if (password != 1110831032) {      //密碼我的學號
            cout << "密碼輸入錯誤" << endl;   //錯誤會叫你再輸入一次
        }
        else {
            cout << "歡迎光臨本系統！" << endl; //正確會跳出這個
            break;
        }

        if (attempts >= max_attempts) {          
            cout << "暫停使用本系統！" << endl;  //錯誤三次會跳出這個
            break;
        }
    } while (true);

    return 0;
}
