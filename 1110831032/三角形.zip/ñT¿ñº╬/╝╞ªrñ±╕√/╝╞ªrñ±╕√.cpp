﻿#include <iostream>
using namespace std;

int main() {
    double a, b, c;
    cout << "請依序輸入三角形的三邊長 a, b, c: ";
    cin >> a >> b >> c;

    if (a <= 0 || b <= 0 || c <= 0) {
        cout << "三角形的邊長必須為正數。" << endl;
    }
    else 
        if (a + b) <= c || (a + c) <= b || (b + c) <= a {
        cout << "無法構成三角形。" << endl;
    };
    else {
        cout << "可以構成三角形。" << endl;
    }

    return 0;
}
