﻿#include <iostream>
using namespace std;

// 自定義函数，接受整数数组的引用作为参数
void sortArray(int(&arr)[5]) {
    // 冒泡排序算法：从数组的第一个元素开始，逐个比较相邻的两个元素，如果顺序错误则交换位置，直到整个数组有序
    for (int i = 0; i < 5 - 1; ++i) {  // 外循环控制比较轮数，每轮确定一个最大值或最小值的位置
        for (int j = 0; j < 5 - i - 1; ++j) {  // 内循环控制每轮比较的次数
            if (arr[j] > arr[j + 1]) {  // 如果相邻两个元素顺序错误
                // 交换数组元素
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int main() {
    int nums[5];  // 定义一个包含5个整数的数组

    // 提示用户输入5个整数
    cout << "請輸入5個整數：" << endl;
    for (int i = 0; i < 5; ++i) {
        cin >> nums[i];  // 逐个接受用户输入的整数
    }

    // 呼叫自定义函数，并将数组作为参数传递给函数，此处采用传址方式
    sortArray(nums);

    // 输出排序后的数组元素
    cout << "從小到大排序後的整數：" << endl;
    for (int i = 0; i < 5; ++i) {
        cout << nums[i] << " ";
    }
    cout << endl;

    return 0;
}
