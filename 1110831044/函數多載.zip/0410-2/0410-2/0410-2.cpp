﻿#include <iostream>
#include <cmath>
#define PI 3.14159265358979323846

using namespace std;

// 定義立方體體積計算函數
void volume(int side, float& result) {
    result = pow(side, 3);
}

// 球體體積計算函數
void volume(float diameter, float& result) {
    float radius = diameter / 2;
    result = (4.0 / 3.0) * PI * pow(radius, 3);
}

// 圓柱體體積計算函數
void volume(float radius, float height, float& result) {
    result = PI * pow(radius, 2) * height;
}

// 長方體體積計算函數
void volume(float length, float width, float height, float& result) {
    result = length * width * height;
}

int main() {
    int choice;
    // 提示用戶輸入要計算體積的形狀選項
    cout << "請輸入要計算體積的形狀：\n1. 立方體\n2. 球體\n3. 圓柱體\n4. 長方體\n";
    cin >> choice;

    float result;
    // 根據用戶選擇的形狀選項，輸入相應的參數，並調用對應的函數計算體積
    switch (choice) {
    case 1: {
        int side;
        cout << "請輸入立方體的邊長：";
        cin >> side;
        // 呼叫立方體體積計算函數
        volume(side, result);
        break;
    }
    case 2: {
        float diameter;
        cout << "請輸入球體的直徑：";
        cin >> diameter;
        // 呼叫球體體積計算函數
        volume(diameter, result);
        break;
    }
    case 3: {
        float radius, height;
        cout << "請輸入圓柱體的底面半徑和高：";
        cin >> radius >> height;
        // 呼叫圓柱體體積計算函數
        volume(radius, height, result);
        break;
    }
    case 4: {
        float length, width, height;
        cout << "請輸入長方體的長、寬和高：";
        cin >> length >> width >> height;
        // 呼叫長方體體積計算函數
        volume(length, width, height, result);
        break;
    }
    default:
        // 如果用戶輸入了無效選項，則顯示錯誤消息
        cout << "無效選項！";
        return 1;
    }

    // 輸出計算結果
    cout << "體積為：" << result << endl;

    return 0;
}
