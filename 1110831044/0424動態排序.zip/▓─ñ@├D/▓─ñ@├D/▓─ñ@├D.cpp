﻿#include <iostream>
#include <string>
using namespace std;

// 定義結構體用來表示學生資訊
struct Student
{
    string name;
    int age;
    string tel;
};

int main()
{
    // 動態配置一個結構體陣列，用來儲存三個學生的資訊
    Student* students = new Student[3];

    // 使用迴圈輸入三位學生的資料
    for (int i = 0; i < 3; i++)
    {
        cout << "輸入第 " << i + 1 << " 位學生的名字: ";
        cin >> students[i].name;
        cout << "年齡: ";
        cin >> students[i].age;
        cout << "電話: ";
        cin >> students[i].tel;
    }

    // 冒泡排序
    for (int i = 1; i <= 2; i++)
    {
        for (int j = 0; j < 3 - i; j++)
        {
            if (students[j].tel > students[j + 1].tel)
            {
                // 如果左邊的學生的電話號碼大於右邊的，則交換位置
                Student temp = students[j];
                students[j] = students[j + 1];
                students[j + 1] = temp;
            }
        }
    }

    // 輸出排序後的資料
    cout << "排序的資料:" << endl;
    for (int i = 0; i < 3; i++)
    {
        cout << "學生姓名: " << students[i].name;
        cout << "\t年齡: " << students[i].age;
        cout << "\t電話: " << students[i].tel << endl;
    }

    // 釋放動態配置的記憶體
    delete[] students;

    return 0;
}
