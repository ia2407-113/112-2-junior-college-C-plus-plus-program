﻿#include <iostream>
#include <string>
using namespace std;

int main()
{
    string str1;
    getline(cin, str1); // 從使用者輸入中讀取一行文字

    int a;
    a = str1.length();

   
    for (int i = 0; i < a; i++)
    {
        str1[i] = toupper(str1[i]); // 將輸入文字全部轉換為大寫
    }

   
    str1[0] = tolower(str1[0]);  // 將第一個字母轉換為小寫

    // 將每個單詞的第一個字母轉換為小寫
    for (int i = 0; i < a; i++)
    {
        if (str1[i] == ' ') // 找到空格，表示單詞的分隔
            str1[i + 1] = tolower(str1[i + 1]); // 將空格後的字母轉換為小寫
    }

    
    cout << str1;

    return 0;
}
