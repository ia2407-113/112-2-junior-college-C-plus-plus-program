﻿#include <iostream>
#include <string>

using namespace std;

int main() {
    const int numFriends = 5; // 定義朋友的數量
    string names[numFriends]; // 用於存儲朋友的姓名的陣列
    string phones[numFriends]; // 用於存儲朋友的電話號碼的陣列

    // 輸入朋友的姓名和電話
    for (int i = 0; i < numFriends; ++i) {
        cout << "請輸入第 " << (i + 1) << " 個朋友的姓名：";
        getline(cin, names[i]); // 使用 getline 函式獲取帶有空格的姓名

        cout << "請輸入第 " << (i + 1) << " 個朋友的電話：";
        getline(cin, phones[i]); // 使用 getline 函式獲取帶有空格的電話號碼
    }

    // 輸入要查詢的朋友姓名
    string queryName;
    cout << "請輸入要查詢的朋友的姓名：";
    getline(cin, queryName); // 使用 getline 函式獲取帶有空格的要查詢的姓名

    // 尋找朋友並輸出電話
    bool found = false; // 用於標記是否找到了指定姓名的朋友
    for (int i = 0; i < numFriends; ++i) {
        if (names[i] == queryName) { // 如果找到了指定姓名的朋友
            cout << "朋友 " << queryName << " 的電話是：" << phones[i] << endl; // 輸出該朋友的電話號碼
            found = true; // 將 found 設置為 true，表示找到了朋友
            break; // 跳出迴圈，因為已經找到了朋友，不需要再繼續尋找
        }
    }

    if (!found) { // 如果找不到指定姓名的朋友
        cout << "找不到名為 " << queryName << " 的朋友。" << endl; // 輸出找不到的訊息
    }

    return 0;
}
